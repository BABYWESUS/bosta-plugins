# Pictures of the Turno look

Copied unchanged from the design folder `docs/pitch-design/turno/` (25 Nov 2026, card UI-SKIN-2): only the
files that `docs/pitch-design/turno/SPEC.md` names. Each copy was compared byte for byte with its original.
None was edited, cropped, recoloured, regenerated or scaled on disk: the factor is 1 for every file. The
plugin halves a big picture in memory when it loads it (`ui/Skin.cpp`, `loadPicture`), which changes
nothing on disk.

How the art was made (the owner's plan, Addendum B2): generated pictures, cut out by script. Each file was
looked at again for UI-SKIN-2: no real brand, logo, medicine name, pill imprint or readable text.

| shipped file | original | pixels | bytes | SHA-256 | scale factor |
|---|---|---|---|---|---|
| `low-2-cut.png` | `docs/pitch-design/turno/char/low-2-cut.png` | 1024 x 1536 | 946,974 | `5e69188947088a104359c86d6e0d299a8258d36163c3b195fd1aff0d6bc9a3a0` | 1 (unchanged) |
| `low-1-c-cut.png` | `docs/pitch-design/turno/char/low-1-c-cut.png` | 1024 x 1536 | 719,535 | `ca203270ed7c6977422d880653d08fc70279dca8199e5fcfd979239d5283ce18` | 1 (unchanged) |
| `zero-cut.png` | `docs/pitch-design/turno/char/zero-cut.png` | 1024 x 1536 | 681,831 | `b417557a6ccd3aea64aa3819d3646305619a3909545acb1e1f1e43bb164b1242` | 1 (unchanged) |
| `high-1-cut.png` | `docs/pitch-design/turno/char/high-1-cut.png` | 1024 x 1536 | 675,262 | `f9de0e138d6f8aca61d49c81e300079bc508a20e449c2fd75944c7335a613124` | 1 (unchanged) |
| `high-2-cut.png` | `docs/pitch-design/turno/char/high-2-cut.png` | 1024 x 1536 | 789,192 | `2aa13a7c4d30c9116434964fefe5fa345392a3546b06e444a5803f5afb563e40` | 1 (unchanged) |
| `bypass-cut.png` | `docs/pitch-design/turno/char/bypass-cut.png` | 1024 x 1536 | 651,570 | `3aa6ce9f4a519160b74583f6ce75a81d1740793bf344f39e4118afce347af52a` | 1 (unchanged) |
| `backdrop-2b.png` | `docs/pitch-design/turno/props/backdrop-2b.png` | 1536 x 1024 | 1,055,306 | `9c8264eb377cfa0cd8d05bceb61e61c46b407e2fb254c23fb79c2de3a6c1b729` | 1 (unchanged) |
| `cup-empty-cut.png` | `docs/pitch-design/turno/props/cup-empty-cut.png` | 1254 x 1254 | 550,156 | `4ea8196e97501e6c35eebbd78691e6b7807b8cffe8eed2eac2aae6a1d53c4ca4` | 1 (unchanged) |
| `cup-full-cut.png` | `docs/pitch-design/turno/props/cup-full-cut.png` | 1254 x 1254 | 597,202 | `257947ccae099c81151e7f4521ba443488a5d018f1b8753e277565daaedf252b` | 1 (unchanged) |
| `joint-bold.png` | `docs/pitch-design/turno/props2/joint-bold.png` | 1536 x 226 | 141,582 | `7317aca5ddde0392eb39bf283502be0e87166d21ec87f0bc0aa1ed9f8e45bfcd` | 1 (unchanged) |
| `ash-row.png` | `docs/pitch-design/turno/props2/ash-row.png` | 1496 x 170 | 151,439 | `8b1aec154965119415ebc1177094efaa79d34c963cf8bb6b62c8ac7d30d87eb5` | 1 (unchanged) |
| `ember-smoke.png` | `docs/pitch-design/turno/props2/ember-smoke.png` | 424 x 592 | 158,792 | `6d87e252fa61d1b73c3bd3c4095d77e4a45e9c3475ab414d93aa107f48434c42` | 1 (unchanged) |
| `ember-coal.png` | `docs/pitch-design/turno/props2/ember-coal.png` | 500 x 314 | 166,644 | `47e467a85b1dfe860f762213d9ccea4a61a66a5d410e10bad67c248d77e13227` | 1 (unchanged) |
| `capsule.png` | `docs/pitch-design/turno/props2/capsule.png` | 204 x 392 | 47,614 | `4740c176af1679e13ee088e559b316a295dd38c0a1d114be98fa99a1edc077b1` | 1 (unchanged) |
| `body-cream.png` | `docs/pitch-design/turno/props2/body-cream.png` | 380 x 380 | 114,557 | `b82dc38097e573313c97331666144016655e27e2aaf1129f82075a6eeb9a3276` | 1 (unchanged) |
| `body-lilac.png` | `docs/pitch-design/turno/props2/body-lilac.png` | 380 x 380 | 114,828 | `940d664d615321145e8908ebbaba866af0c60e42614597693079efd163681eab` | 1 (unchanged) |
| `score.png` | `docs/pitch-design/turno/props2/score.png` | 380 x 380 | 2,640 | `abfb92b1bbc7c7e637d8fd952d0850f92793e1f30b6830f5e9585335eff399dd` | 1 (unchanged) |
| `top-hex.png` | `docs/pitch-design/turno/props2/top-hex.png` | 380 x 380 | 110,688 | `a3516c1e7347e59e44206d82fb712e2211a1f1c376487409d6f9505628206916` | 1 (unchanged) |
